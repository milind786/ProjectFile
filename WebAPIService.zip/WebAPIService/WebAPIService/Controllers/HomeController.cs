﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebAPIService.Models;
namespace WebAPIService.Controllers
{
    public class HomeController : ApiController
    {
        

        private static List<CustomerModel> custModelDetail = new List<CustomerModel>()
        {
                new CustomerModel() { CustomerId =1, FirstName = "Pravin", LastName = "Kale", Email ="pravin123@gmail.com" , PhoneNumber ="6858483828" ,Status ="Active"},
                new CustomerModel() { CustomerId =2 ,FirstName = "Hemant", LastName = "Deshpande", Email ="Heamnt.Deshpande@yahoo.com" , PhoneNumber ="9887653456" ,Status ="Active"},
                new CustomerModel() { CustomerId =3 , FirstName = "Amit", LastName = "Patel", Email ="amitpatel345@gmail.co.in" , PhoneNumber ="9293456879" ,Status ="Active"},
                new CustomerModel() { CustomerId =4 ,FirstName = "Rajnath", LastName = "Singh", Email ="rajnathSingh888@yahoo.co.in" , PhoneNumber ="9558483827" ,Status ="Active"},
                new CustomerModel() { CustomerId =5 , FirstName = "Prajakta", LastName = "Patil", Email ="praj1234@gmail.com" , PhoneNumber ="9867920398" ,Status ="Active"},
                new CustomerModel() { CustomerId =6 ,FirstName = "Shantarm", LastName = "Ingale", Email ="shant888@gmail.com" , PhoneNumber ="8976435643" ,Status ="Active"},
         };



        [HttpGet]
        public IEnumerable<CustomerModel> GetCustomers()
        {
            return custModelDetail;
        }

        [HttpGet]
        public CustomerModel GetCustomer(int id)
        {
            CustomerModel customerModel = custModelDetail.Find(p => p.CustomerId == id);

            if (customerModel == null)
                throw new HttpResponseException(HttpStatusCode.NotFound);
            else
                return customerModel;
        }


        [HttpPost]
        public HttpResponseMessage PostCustomer(CustomerModel customerModel)
        {
            HttpResponseMessage httpResponse = null;
            if (customerModel == null)
                httpResponse = new HttpResponseMessage(HttpStatusCode.BadRequest);
            if (ModelState.IsValid)
            {
                custModelDetail.Add(customerModel);
                httpResponse = new HttpResponseMessage(HttpStatusCode.Created);
            }

            return httpResponse;
        }

        [HttpDelete]
        public IEnumerable<CustomerModel> DeleteCustomer(int id)
        {
            CustomerModel custModel = custModelDetail.Find(c => c.CustomerId == id);
            custModelDetail.Remove(custModel);

            return custModelDetail;
        }

        [HttpPut]
        public HttpResponseMessage UpdateCustomer(CustomerModel custModel)
        {
            CustomerModel objcustModel = custModelDetail.Find(c => c.CustomerId == c.CustomerId);

            if (objcustModel == null)
                return new HttpResponseMessage(HttpStatusCode.NotFound);

            objcustModel.CustomerId = custModel.CustomerId;
            objcustModel.FirstName = custModel.FirstName;
            objcustModel.LastName = custModel.LastName;
            objcustModel.Email = custModel.Email;
            objcustModel.PhoneNumber = custModel.PhoneNumber;
            objcustModel.Status = custModel.Status;

            return new HttpResponseMessage(HttpStatusCode.OK);
        }
    
   
    }
}
